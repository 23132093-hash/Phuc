# Nối từ TOEIC – PWA

Bản này đã được chuyển thành Progressive Web App (PWA).

## Cài trên iPhone
1. Đưa toàn bộ thư mục này lên một website có HTTPS.
2. Mở `index.html` bằng Safari trên iPhone.
3. Bấm nút Chia sẻ.
4. Chọn **Thêm vào Màn hình chính**.
5. Bấm **Thêm**.

Sau đó sẽ có icon “Nối từ TOEIC” trên màn hình chính và mở ở chế độ giống app.

## Offline
Service Worker sẽ lưu game vào bộ nhớ cache sau lần mở đầu tiên. Sau khi đã mở/để trang tải hoàn tất ít nhất một lần, game có thể chạy không mạng.

Lưu ý: chức năng liên kết Google Translate trong game vẫn cần Internet nếu người dùng bấm vào nó. Phần chơi và dữ liệu game được đóng gói cục bộ.
